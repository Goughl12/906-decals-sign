# 906 Decals & Signs — custom Stripe storefront starter

A runnable custom Node/Express storefront with a responsive homepage, configurable products, artwork uploads, server-side price validation, Stripe-hosted checkout, and webhook payment confirmation. This is an **initial starter**, not a production-ready store.

## Start locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and enter your **Stripe test** secret key.
4. Run `npm start` and visit `http://localhost:3000`.
5. For webhook testing use Stripe CLI: `stripe listen --forward-to localhost:3000/api/stripe-webhook`, and copy its signing secret into `.env`.

## Important before launching
- Replace demo product prices and vague size tiers with your real SKU dimensions, pricing and shipping rules.
- Add taxes, shipping address collection/rates, refund policy, privacy policy, terms, business contact details and confirmation emails.
- Configure a verified Stripe account, production HTTPS domain and webhook endpoint; switch to live keys only after end-to-end testing.
- Store orders and uploads in a managed private database/object store, not the local filesystem. Restrict admin access; add malware/file-content scanning, rate limiting, cleanup of abandoned uploads, monitoring and backups.
- Implement fulfillment workflow and an authenticated admin dashboard. Add delivery tracking and customer support.
- Never expose Stripe secret keys to frontend code or version control. `private-data/` contains customer details and must remain private.
- The return page is **not** proof of payment. The verified Stripe webhook marks an order paid.

This implementation is original and does not copy the source code or assets of the referenced site.
